# Twitter Data Wrangling Project

 The Data Wrangling Project was meant to challenge the learner in various ways:
 * Gather Data from various sources and in a variety of formats
 * Assess its quality and tidiness
 * Cleaning the data
 * Performing analysis on the data
 * Showcasing the efforts through data visualization.
 * Language : Python
 * Libraries Used: Pandas, Matplolib, Tweepy, Requests, JSON
 * Write Up : [‘We Rate Dogs’ : Twitter Data Analysis](https://medium.com/@spetiwala0/we-rate-dogs-twitter-data-analysis-672e1a8903b4)
