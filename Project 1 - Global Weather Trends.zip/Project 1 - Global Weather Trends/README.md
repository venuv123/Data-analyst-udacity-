 ## Project 1 - Global Weather Trends 
 In this project, I have analysed local and global temperature data and compared the temperature trends with where I live to overall global   temperatures
